<?php 
	require_once __DIR__."/../../config.php";
	require_once "../modelos/candidato.php";
	require_once "../crud/crud_candidato.php";
	require_once "../modelos/empresa.php";
	require_once "../crud/crud_empresa.php";

	function verificar_candidato(){
		session_start();
		session_destroy();
		session_start();
			$login =  $_POST['login'];
			$senha =  $_POST['senha'];
			$crud = new crud_Candidato();
			$listaCandidatos = $crud->getAll();
			$usuario_existe = false;
			foreach ($listaCandidatos as $listaCandidato){

	        //colar aqui o if
	        if ($login == $listaCandidato['login'] AND $senha == $listaCandidato['senha'] ) {
	            $usuario_existe = true;
	            $_SESSION = $listaCandidato;
	            $_SESSION['usuario_online'] = true;
	        }
	    }
	    if ($usuario_existe == true) {
	    	include '../../assets/cabecalho.html'; 
	    	include'../visao/funcional.php';	
	    }
	    $usuario_existe = false;
	    $crud = new crud_Empresa();
		$lista_empresas = $crud->getAll();
		foreach ($lista_empresas as $lista_empresa){ 
	    if ($login == $lista_empresa['login'] AND $senha == $lista_empresa['senha']) {
	    		$usuario_existe = true;
	            $_SESSION = $lista_empresa;
	            $_SESSION['usuario_online'] = true;
	    	}
	    }
	    if ($usuario_existe == true) {
	    	include '../../assets/cabecalho.html'; 
	    	include __DIR__.'/../visao/admin/listar_candidatos.php';	
	    }
	    else {
	    	header('Location: ../../index.php');
	    }
	}
	if (isset($_GET['acao'])){
		$acao = $_GET['acao'];
	} else{
		header('Location: ../../index.php');
}
	
	
	function login(){
		include  '../../assets/cabecalho.html';
		include  '../visao/login_candidato.php';
	}
switch ($acao) {
	case 'login':
		login();
	break;
	case 'verificar_candidato':
		verificar_candidato();		
	break;
	default:
			
	break;
}