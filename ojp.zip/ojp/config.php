<?php

	
	const BASE_URL = 'http://localhost/mario/OJP/ojp/';

	const ASSETS_URL = BASE_URL + 'assets/';
